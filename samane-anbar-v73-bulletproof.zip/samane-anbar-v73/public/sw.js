/* ============================================================
   نسخه ۷۴ (اصلاح نهایی) — Nuclear Cleanup Service Worker
   ============================================================
   این Service Worker به‌محض نصب، تمام کش‌های قدیمی را پاک می‌کند،
   خودش را unregister می‌کند و دیگر هیچ درخواستی را拦截 نمی‌کند.
   این کار باعث می‌شود مرورگر همیشه نسخه تازه فایل‌ها را از سرور بگیرد.

   نحوه کار:
   ۱) مرورگر همیشه /sw.js را از شبکه (نه کش) می‌گیرد
   ۲) وقتی این نسخه جدید را می‌بیند، آن را نصب می‌کند
   ۳) این SW با skipWaiting و clients.claim فوراً فعال می‌شود
   ۴) تمام کش‌ها را پاک می‌کند
   ۵) خودش را unregister می‌کند
   ۶) بعد از این، همه درخواست‌ها مستقیم به سرور می‌روند
   ============================================================ */

// ====== Install: پاک‌سازی فوری ======
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    try {
      // پاک‌سازی تمام کش‌های قدیمی
      const keys = await caches.keys();
      await Promise.all(keys.map(k => {
        console.log('Deleting cache:', k);
        return caches.delete(k);
      }));
      // فعال‌سازی فوری
      await self.skipWaiting();
      console.log('نسخه ۷۴ SW: نصب شد، کش‌ها پاک شدند');
    } catch (e) {
      console.error('SW install error:', e);
    }
  })());
});

// ====== Activate: پاک‌سازی نهایی و takeover ======
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    try {
      // پاک‌سازی مجدد کش‌ها
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
      // تصرف همه کلاینت‌ها (تب‌های باز)
      await self.clients.claim();
      // unregister خودکار — دیگر نیازی به SW نیست
      await self.registration.unregister();
      // اطلاع به همه کلاینت‌ها که باید رفرش کنند
      const clients = await self.clients.matchAll({ type: 'window' });
      clients.forEach(client => {
        client.postMessage({ type: 'SW_CLEANUP_DONE', action: 'RELOAD' });
      });
      console.log('نسخه ۷۴ SW: فعال شد، خود unregister کرد، کلاینت‌ها notified شدند');
    } catch (e) {
      console.error('SW activate error:', e);
    }
  })());
});

// ====== Fetch: هیچ کاری نکن — مرورگر خودش از شبکه بگیر ======
self.addEventListener('fetch', event => {
  // عمداً خالی — هیچ درخواستی را拦截 نکن
  return;
});

// ====== Message: اگر کلاینت درخواست reload کرد ======
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'FORCE_RELOAD') {
    self.clients.matchAll({ type: 'window' }).then(clients => {
      clients.forEach(c => c.navigate(c.url));
    });
  }
});
