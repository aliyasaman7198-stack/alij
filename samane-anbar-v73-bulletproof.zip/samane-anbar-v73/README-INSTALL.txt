============================================================
  Samane Anbar v73 - Ready-to-Use Package
  Warehouse Management System (Persian)
============================================================

CONTENTS:
  start.bat              <- Double-click this to launch
  server.js              <- Backend (Node.js + Express + SQLite)
  package.json           <- Dependencies list
  public/index.html      <- SPA frontend (321 KB)
  public/sw.js           <- Service Worker
  public/manifest.json   <- PWA manifest
  public/icons/          <- App icons (5 PNG files)

REQUIREMENTS:
  - Windows 10/11 (64-bit)
  - Node.js v18+ (LTS recommended) - https://nodejs.org/

QUICK START:
  1. Extract this ZIP to a folder (e.g., Desktop\warehouse)
  2. Double-click start.bat
  3. Wait for npm install to finish (first run only, ~30 sec)
  4. Browser opens automatically at http://localhost:8080

IF start.bat REPORTS MISSING FILES:
  Windows Defender likely quarantined them during extraction.
  - Open Windows Security -> Virus & threat protection -> Protection history
  - Restore any quarantined files
  - OR add this folder as an Exclusion in Defender settings
  - OR re-extract using 7-Zip (right-click ZIP -> 7-Zip -> Extract here)

STOP THE SERVER:
  Press Ctrl+C in the black command window.

DATA LOCATION:
  All data is stored in: data\database.sqlite (auto-created)
  Backups in: data\backups\

DEFAULT PORT: 8080
============================================================
