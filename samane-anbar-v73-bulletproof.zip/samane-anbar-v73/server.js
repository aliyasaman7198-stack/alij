/* ============================================================
   نسخه ۷۳ — سامانه مدیریت انبار (سرور)
   ============================================================
   بهبودهای نسخه ۷۳ نسبت به ۷۲:
   ۱) امنیت کامل:
      - هش کردن پسوردها با bcryptjs
      - Session مبتنی بر cookie با httpOnly و ۷ روز اعتبار
      - RBAC روی همه endpoint‌ها (manager / storekeeper / viewer)
      - endpoint‌های /api/login, /api/logout, /api/me
      - مهاجرت خودکار پسوردهای قدیمی (plain text) به bcrypt
   ۲) کارایی (از نسخه ۷۲ حفظ شده):
      - ۱۷ ایندکس SQLite
      - کش درون‌حافظه‌ای برای warehouses/categories/settings
      - Debounce برای saveDatabase
   ۳) Cardex:
      - endpoint جدید /api/cardex?productId=X&from=Y&to=Z
   ۴) PWA:
      - سرو فایل‌های manifest.json, sw.js, icons/
      - تنظیم headerهای مناسب برای Service Worker
   بدون تغییر در ساختار API endpoints موجود (به‌جز افزودن auth)
   ============================================================ */
const express = require('express');
const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const open = require('open');
const bcrypt = require('bcryptjs');
// Embedded fallback content for critical public/ files (auto-generated).
// Used when Windows Defender or other tools quarantine files during extraction.
let embeddedAssets = {};
try { embeddedAssets = require('./embedded-assets'); } catch (e) { console.warn('[embedded-assets] not loaded:', e.message); }
const app = express();
const PORT = 8080;
const DB_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DB_DIR, 'database.sqlite');
const BACKUP_DIR = path.join(DB_DIR, 'backups');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
let db = null, SQL = null;

// ====== Session store درون‌حافظه‌ای ======
// نگاشت token -> {userId, username, fullName, role, expires}
const sessions = new Map();
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // ۷ روز
const SESSION_COOKIE_NAME = 'wh_session';

// پاک‌سازی session‌های منقضی (هر ساعت)
setInterval(() => {
  const now = Date.now();
  for (const [token, sess] of sessions) {
    if (sess.expires < now) sessions.delete(token);
  }
}, 3600000);

// ====== کش درون‌حافظه‌ای ======
let _warehousesCache = null, _categoriesCache = null, _settingsCache = null;
function invalidateCache(key) {
  if (key === 'warehouses') _warehousesCache = null;
  else if (key === 'categories') _categoriesCache = null;
  else if (key === 'settings') _settingsCache = null;
  else { _warehousesCache = null; _categoriesCache = null; _settingsCache = null; }
}

// ====== Debounce برای saveDatabase ======
let _saveTimer = null;
const SAVE_DEBOUNCE_MS = 500;
function saveDatabase() {
  if (_saveTimer) clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    _saveTimer = null;
    try { fs.writeFileSync(DB_PATH, Buffer.from(db.export())); } catch (e) { console.error('Save error:', e.message); }
  }, SAVE_DEBOUNCE_MS);
}
function saveDatabaseNow() {
  if (_saveTimer) { clearTimeout(_saveTimer); _saveTimer = null; }
  try { fs.writeFileSync(DB_PATH, Buffer.from(db.export())); } catch (e) { console.error('Save error:', e.message); }
}

async function loadDatabase() {
  SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) { db = new SQL.Database(fs.readFileSync(DB_PATH)); }
  else { db = new SQL.Database(); }
  initDatabase();
  await migratePasswordsToBcrypt();
  saveDatabaseNow();
}

function initDatabase() {
  db.run(`CREATE TABLE IF NOT EXISTS personnel(id TEXT PRIMARY KEY,personnelCode TEXT,phone TEXT,fullName TEXT,address TEXT,notes TEXT,createdAt TEXT,deletedAt TEXT);CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT,categoryId TEXT,unit TEXT,warehouseId TEXT,initialStock REAL,initialDefectiveStock REAL,alertThreshold REAL,createdAt TEXT,deletedAt TEXT);CREATE TABLE IF NOT EXISTS movements(id TEXT PRIMARY KEY,ts TEXT,dateISO TEXT,dateDisplay TEXT,personId TEXT,productId TEXT,warehouseId TEXT,type TEXT,qty REAL,serial TEXT,supplier TEXT,notes TEXT,documentNo TEXT,fromPersonId TEXT,toPersonId TEXT,deletedAt TEXT);CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT,fullName TEXT,password TEXT,role TEXT,createdAt TEXT);CREATE TABLE IF NOT EXISTS warehouses(id TEXT PRIMARY KEY,name TEXT,code TEXT,createdAt TEXT);CREATE TABLE IF NOT EXISTS categories(id TEXT PRIMARY KEY,name TEXT,createdAt TEXT);CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,ts TEXT,userId TEXT,username TEXT,fullName TEXT,role TEXT,action TEXT,entity TEXT,entityId TEXT,beforeData TEXT,afterData TEXT,extra TEXT);CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);`);
  // ایندکس‌ها (نسخه ۷۲)
  db.run(`
    CREATE INDEX IF NOT EXISTS idx_movements_productId ON movements(productId);
    CREATE INDEX IF NOT EXISTS idx_movements_personId ON movements(personId);
    CREATE INDEX IF NOT EXISTS idx_movements_fromPersonId ON movements(fromPersonId);
    CREATE INDEX IF NOT EXISTS idx_movements_toPersonId ON movements(toPersonId);
    CREATE INDEX IF NOT EXISTS idx_movements_ts ON movements(ts);
    CREATE INDEX IF NOT EXISTS idx_movements_deletedAt ON movements(deletedAt);
    CREATE INDEX IF NOT EXISTS idx_movements_type ON movements(type);
    CREATE INDEX IF NOT EXISTS idx_movements_warehouseId ON movements(warehouseId);
    CREATE INDEX IF NOT EXISTS idx_products_deletedAt ON products(deletedAt);
    CREATE INDEX IF NOT EXISTS idx_products_categoryId ON products(categoryId);
    CREATE INDEX IF NOT EXISTS idx_products_warehouseId ON products(warehouseId);
    CREATE INDEX IF NOT EXISTS idx_personnel_deletedAt ON personnel(deletedAt);
    CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit(ts);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit(entity);
    CREATE INDEX IF NOT EXISTS idx_audit_entityId ON audit(entityId);
    CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
    CREATE INDEX IF NOT EXISTS idx_settings_key ON settings(key);
  `);
  const whR = db.exec('SELECT COUNT(*) FROM warehouses');
  if (whR.length > 0 && whR[0].values[0][0] === 0) {
    db.run('INSERT INTO warehouses(id,name,code,createdAt) VALUES(?,?,?,?)', [crypto.randomUUID(), 'انبار اصلی', 'W01', new Date().toISOString()]);
  }
  const catR = db.exec('SELECT COUNT(*) FROM categories');
  if (catR.length > 0 && catR[0].values[0][0] === 0) {
    ['مصرفی', 'ابزار', 'یراق‌آلات', 'تجهیزات', 'سایر'].forEach(n => db.run('INSERT INTO categories(id,name,createdAt) VALUES(?,?,?)', [crypto.randomUUID(), n, new Date().toISOString()]));
  }
  saveDatabase();
}

// ====== مهاجرت پسوردهای قدیمی به bcrypt ======
// نسخه ۷۴ (اصلاح): این تابع فقط پسوردهای plain text رو مهاجرت می‌ده
// پسوردهای هش‌شده با الگوریتم قدیمی (h...:length) در زمان login مهاجرت داده می‌شن
// چون برای مهاجرت، نیاز به رمز اصلی داریم
async function migratePasswordsToBcrypt() {
  const users = queryAll('SELECT id, username, password FROM users');
  for (const u of users) {
    // فقط plain text (نه bcrypt، نه الگوریتم قدیمی)
    if (u.password && !/^\$2[aby]\$\d{2}\$/.test(u.password) && !isOldHashFormat(u.password)) {
      const hashed = bcrypt.hashSync(u.password, 10);
      db.run('UPDATE users SET password=? WHERE id=?', [hashed, u.id]);
      console.log('Plain text password migrated to bcrypt for user:', u.username);
    }
  }
}

function queryAll(sql, params = []) {
  const s = db.prepare(sql);
  s.bind(params);
  const r = [];
  while (s.step()) r.push(s.getAsObject());
  s.free();
  return r;
}
function insertOrUpdate(t, item, cols) {
  // اگه id نبود، یکی تولید کن (در غیر این صورت sql.js روی bind undefined خطا می‌دهد)
  if (!item.id) item.id = crypto.randomUUID();
  db.run(`DELETE FROM ${t} WHERE id=?`, [item.id]);
  db.run(`INSERT INTO ${t}(${cols.join(', ')}) VALUES(${cols.map(() => '?').join(', ')})`, cols.map(c => item[c] !== undefined ? item[c] : null));
  saveDatabase();
}

// ====== Middleware ها ======
app.use(express.json({ limit: '50mb' }));

// parse cookies
function parseCookies(req, res, next) {
  const cookies = {};
  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    cookieHeader.split(';').forEach(c => {
      const parts = c.trim().split('=');
      if (parts.length >= 2) cookies[parts[0]] = decodeURIComponent(parts.slice(1).join('='));
    });
  }
  req.cookies = cookies;
  next();
}
app.use(parseCookies);

// فایل‌های استاتیک — نسخه ۷۴: جلوگیری از کش همیشه (برای حل مشکل آپدیت)
// نسخه Bulletproof: index:false تا express.static برای index.html خطای ENOENT ندهد
// (سرو index.html توسط fallback middleware و catch-all route با خودِ embedded انجام می‌شود)
app.use(express.static(path.join(__dirname, 'public'), {
  etag: false,
  index: false,
  setHeaders: (res, filePath) => {
    // همه فایل‌ها نباید کش شوند — برای اطمینان از بارگذاری نسخه جدید
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }
}));

// ====== Auth Middleware ======
function requireAuth(req, res, next) {
  const token = req.cookies[SESSION_COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'Unauthorized', code: 'NO_SESSION' });
  const sess = sessions.get(token);
  if (!sess) return res.status(401).json({ error: 'Unauthorized', code: 'INVALID_SESSION' });
  if (sess.expires < Date.now()) {
    sessions.delete(token);
    return res.status(401).json({ error: 'Unauthorized', code: 'EXPIRED_SESSION' });
  }
  req.user = sess;
  next();
}

function requireRole(...roles) {
  return (req, res, next) => {
    requireAuth(req, res, () => {
      if (!roles.includes(req.user.role)) {
        return res.status(403).json({ error: 'Forbidden', code: 'INSUFFICIENT_ROLE' });
      }
      next();
    });
  };
}

// برای endpoint‌هایی که در حالت "اولین راه‌اندازی" هم باید در دسترس باشند
function optionalAuth(req, res, next) {
  const token = req.cookies[SESSION_COOKIE_NAME];
  if (token) {
    const sess = sessions.get(token);
    if (sess && sess.expires > Date.now()) req.user = sess;
  }
  next();
}

// ====== Login / Logout / Me ======
// نسخه ۷۴ (اصلاح): تابع هش قدیمی برای تشخیص و مهاجرت پسوردهای قدیمی
function oldHashPassword(pw) {
  let h = 0;
  for (let i = 0; i < pw.length; i++) {
    h = ((h << 5) - h) + pw.charCodeAt(i);
    h |= 0;
  }
  return 'h' + Math.abs(h).toString(36) + ':' + pw.length;
}
function isOldHashFormat(stored) {
  // الگوریتم قدیمی: h + hash + : + length — مثلاً 'habc123:8'
  return typeof stored === 'string' && /^h[a-z0-9]+:\d+$/.test(stored);
}

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'نام کاربری و رمز عبور الزامی است' });
  // بررسی تعداد کاربران — اگه هیچ کاربری نبود، login غیرممکن است
  const users = queryAll('SELECT * FROM users');
  if (!users.length) return res.status(404).json({ error: 'هنوز کاربری ثبت نشده است', code: 'NO_USERS' });
  const user = users.find(u => u.username === username);
  if (!user) return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است' });
  // بررسی پسورد
  let valid = false;
  let needsMigration = false;
  try {
    if (/^\$2[aby]\$\d{2}\$/.test(user.password)) {
      // پسورد با bcrypt هش شده — مقایسه مستقیم
      valid = bcrypt.compareSync(password, user.password);
    } else if (isOldHashFormat(user.password)) {
      // پسورد با الگوریتم قدیمی هش شده — مقایسه با هش قدیمی
      valid = (user.password === oldHashPassword(password));
      needsMigration = valid; // اگه درست بود، باید به bcrypt مهاجرت بشه
    } else if (user.password) {
      // پسورد plain text (مهاجرت نشده)
      valid = (user.password === password);
      needsMigration = valid;
    }
  } catch (e) { valid = false; }
  if (!valid) return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است' });
  // مهاجرت به bcrypt (اگه نیاز بود)
  if (needsMigration) {
    try {
      const hashed = bcrypt.hashSync(password, 10);
      db.run('UPDATE users SET password=? WHERE id=?', [hashed, user.id]);
      saveDatabase();
      console.log('Password migrated to bcrypt for user:', user.username);
    } catch (e) { console.error('Migration error:', e.message); }
  }
  // ساخت session
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, {
    userId: user.id,
    username: user.username,
    fullName: user.fullName,
    role: user.role,
    expires: Date.now() + SESSION_TTL_MS
  });
  // تنظیم cookie
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    maxAge: SESSION_TTL_MS,
    sameSite: 'lax',
    path: '/'
  });
  res.json({
    success: true,
    user: { id: user.id, username: user.username, fullName: user.fullName, role: user.role }
  });
});

app.post('/api/logout', (req, res) => {
  const token = req.cookies[SESSION_COOKIE_NAME];
  if (token) sessions.delete(token);
  res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
  res.json({ success: true });
});

app.get('/api/me', requireAuth, (req, res) => {
  res.json({ user: { id: req.user.userId, username: req.user.username, fullName: req.user.fullName, role: req.user.role } });
});

// ====== Personnel ======
app.get('/api/personnel', requireAuth, (req, res) => res.json(queryAll('SELECT * FROM personnel ORDER BY createdAt DESC')));
app.post('/api/personnel', requireRole('manager', 'storekeeper'), (req, res) => { insertOrUpdate('personnel', req.body, ['id', 'personnelCode', 'phone', 'fullName', 'address', 'notes', 'createdAt', 'deletedAt']); res.json({ success: true }); });
app.delete('/api/personnel/:id', requireRole('manager', 'storekeeper'), (req, res) => { db.run('DELETE FROM personnel WHERE id=?', [req.params.id]); saveDatabase(); res.json({ success: true }); });

// ====== Products ======
app.get('/api/products', requireAuth, (req, res) => res.json(queryAll('SELECT * FROM products ORDER BY createdAt DESC')));
app.post('/api/products', requireRole('manager', 'storekeeper'), (req, res) => { insertOrUpdate('products', req.body, ['id', 'name', 'categoryId', 'unit', 'warehouseId', 'initialStock', 'initialDefectiveStock', 'alertThreshold', 'createdAt', 'deletedAt']); res.json({ success: true }); });
app.delete('/api/products/:id', requireRole('manager', 'storekeeper'), (req, res) => { db.run('DELETE FROM products WHERE id=?', [req.params.id]); saveDatabase(); res.json({ success: true }); });

// ====== Movements ======
app.get('/api/movements', requireAuth, (req, res) => res.json(queryAll('SELECT * FROM movements ORDER BY ts DESC')));
app.post('/api/movements', requireRole('manager', 'storekeeper'), (req, res) => { insertOrUpdate('movements', req.body, ['id', 'ts', 'dateISO', 'dateDisplay', 'personId', 'productId', 'warehouseId', 'type', 'qty', 'serial', 'supplier', 'notes', 'documentNo', 'fromPersonId', 'toPersonId', 'deletedAt']); res.json({ success: true }); });
app.delete('/api/movements/:id', requireRole('manager', 'storekeeper'), (req, res) => { db.run('DELETE FROM movements WHERE id=?', [req.params.id]); saveDatabase(); res.json({ success: true }); });

// ====== Cardex (نسخه ۷۳) ======
app.get('/api/cardex', requireAuth, (req, res) => {
  const { productId, from, to } = req.query;
  if (!productId) return res.status(400).json({ error: 'productId الزامی است' });
  // کوئری همه movements این کالا (با فیلتر تاریخ اختیاری)
  let sql = 'SELECT * FROM movements WHERE productId=? AND deletedAt IS NULL';
  const params = [productId];
  if (from) { sql += ' AND dateISO >= ?'; params.push(from); }
  if (to) { sql += ' AND dateISO <= ?'; params.push(to); }
  sql += ' ORDER BY ts ASC';
  res.json(queryAll(sql, params));
});

// ====== Users ======
// GET /api/has-users — public endpoint (no auth) — برای تصمیم‌گیری درباره نمایش تب ورود یا ثبت‌نام
app.get('/api/has-users', (req, res) => {
  const r = db.exec('SELECT COUNT(*) FROM users');
  const count = r.length > 0 ? r[0].values[0][0] : 0;
  res.json({ hasUsers: count > 0, count: count });
});
// GET /api/users — فقط مدیر (در غیر این صورت فقط تعداد و نقش‌ها)
app.get('/api/users', requireAuth, (req, res) => {
  const users = queryAll('SELECT * FROM users ORDER BY createdAt DESC');
  // پنهان کردن پسورد در پاسخ
  const safe = users.map(u => ({ ...u, password: '***' }));
  res.json(safe);
});
app.post('/api/users', async (req, res) => {
  // نسخه ۷۳: اگر هیچ کاربری وجود ندارد، اجازه ثبت‌نام اولین مدیر را بدون auth بده
  const userCount = db.exec('SELECT COUNT(*) FROM users');
  const count = userCount.length > 0 ? userCount[0].values[0][0] : 0;
  if (count > 0) {
    // کاربران موجود هستند — نیاز به نقش مدیر داریم
    const token = req.cookies[SESSION_COOKIE_NAME];
    if (!token) return res.status(401).json({ error: 'Unauthorized', code: 'NO_SESSION' });
    const sess = sessions.get(token);
    if (!sess || sess.expires < Date.now()) return res.status(401).json({ error: 'Unauthorized', code: 'INVALID_SESSION' });
    if (sess.role !== 'manager') return res.status(403).json({ error: 'Forbidden', code: 'INSUFFICIENT_ROLE' });
  }
  const item = req.body;
  // بررسی نام کاربری تکراری
  if (item.username) {
    const existing = queryAll('SELECT id FROM users WHERE username=?', [item.username]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'این نام کاربری قبلاً استفاده شده است' });
    }
  }
  // اگه پسورد فرستاده شده plain text است (نه هش)، آن را هش کن
  if (item.password && !/^\$2[aby]\$\d{2}\$/.test(item.password)) {
    item.password = bcrypt.hashSync(item.password, 10);
  }
  // اگه اولین کاربر است، نقش manager را اجبار کن
  if (count === 0) item.role = 'manager';
  insertOrUpdate('users', item, ['id', 'username', 'fullName', 'password', 'role', 'createdAt']);
  res.json({ success: true });
});
app.delete('/api/users/:id', requireRole('manager'), (req, res) => {
  // جلوگیری از حذف آخرین مدیر
  const users = queryAll('SELECT * FROM users WHERE role=?', ['manager']);
  if (users.length <= 1 && users[0] && users[0].id === req.params.id) {
    return res.status(400).json({ error: 'آخرین مدیر قابل حذف نیست' });
  }
  db.run('DELETE FROM users WHERE id=?', [req.params.id]); saveDatabase(); res.json({ success: true });
});

// ====== Warehouses ======
app.get('/api/warehouses', requireAuth, (req, res) => {
  if (!_warehousesCache) _warehousesCache = queryAll('SELECT * FROM warehouses ORDER BY createdAt');
  res.json(_warehousesCache);
});
app.post('/api/warehouses', requireRole('manager'), (req, res) => { insertOrUpdate('warehouses', req.body, ['id', 'name', 'code', 'createdAt']); invalidateCache('warehouses'); res.json({ success: true }); });
app.delete('/api/warehouses/:id', requireRole('manager'), (req, res) => { db.run('DELETE FROM warehouses WHERE id=?', [req.params.id]); saveDatabase(); invalidateCache('warehouses'); res.json({ success: true }); });

// ====== Categories ======
app.get('/api/categories', requireAuth, (req, res) => {
  if (!_categoriesCache) _categoriesCache = queryAll('SELECT * FROM categories ORDER BY createdAt');
  res.json(_categoriesCache);
});
app.post('/api/categories', requireRole('manager'), (req, res) => { insertOrUpdate('categories', req.body, ['id', 'name', 'createdAt']); invalidateCache('categories'); res.json({ success: true }); });
app.delete('/api/categories/:id', requireRole('manager'), (req, res) => { db.run('DELETE FROM categories WHERE id=?', [req.params.id]); saveDatabase(); invalidateCache('categories'); res.json({ success: true }); });

// ====== Audit ======
app.get('/api/audit', requireAuth, (req, res) => res.json(queryAll('SELECT * FROM audit ORDER BY ts DESC LIMIT 2000')));
app.post('/api/audit', requireAuth, (req, res) => { insertOrUpdate('audit', req.body, ['id', 'ts', 'userId', 'username', 'fullName', 'role', 'action', 'entity', 'entityId', 'beforeData', 'afterData', 'extra']); res.json({ success: true }); });
app.post('/api/audit/clear', requireRole('manager'), (req, res) => { db.run('DELETE FROM audit'); saveDatabase(); res.json({ success: true }); });

// ====== Settings ======
app.get('/api/settings', requireAuth, (req, res) => {
  if (!_settingsCache) {
    const rows = queryAll('SELECT * FROM settings');
    const s = {};
    rows.forEach(r => s[r.key] = r.value);
    if (!s.orgName) s.orgName = 'اداره گاز شهر حصار گرمخان';
    _settingsCache = s;
  }
  res.json(_settingsCache);
});
app.post('/api/settings', requireRole('manager'), (req, res) => {
  const { key, value } = req.body;
  db.run('DELETE FROM settings WHERE key=?', [key]);
  db.run('INSERT INTO settings(key,value) VALUES(?,?)', [key, value]);
  saveDatabase(); invalidateCache('settings'); res.json({ success: true });
});

// ====== Backup / Restore ======
app.post('/api/backup', requireRole('manager'), (req, res) => {
  try {
    saveDatabaseNow();
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    fs.writeFileSync(path.join(BACKUP_DIR, `backup_${ts}.sqlite`), Buffer.from(db.export()));
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});
app.post('/api/restore', requireRole('manager'), (req, res) => {
  try {
    const { data } = req.body;
    if (!data) throw new Error('No data');
    ['personnel', 'products', 'movements', 'warehouses', 'categories', 'audit'].forEach(t => db.run(`DELETE FROM ${t}`));
    if (data.personnel) data.personnel.forEach(i => insertOrUpdate('personnel', i, ['id', 'personnelCode', 'phone', 'fullName', 'address', 'notes', 'createdAt', 'deletedAt']));
    if (data.products) data.products.forEach(i => insertOrUpdate('products', i, ['id', 'name', 'categoryId', 'unit', 'warehouseId', 'initialStock', 'initialDefectiveStock', 'alertThreshold', 'createdAt', 'deletedAt']));
    if (data.movements) data.movements.forEach(i => insertOrUpdate('movements', i, ['id', 'ts', 'dateISO', 'dateDisplay', 'personId', 'productId', 'warehouseId', 'type', 'qty', 'serial', 'supplier', 'notes', 'documentNo', 'fromPersonId', 'toPersonId', 'deletedAt']));
    if (data.warehouses) data.warehouses.forEach(i => insertOrUpdate('warehouses', i, ['id', 'name', 'code', 'createdAt']));
    if (data.categories) data.categories.forEach(i => insertOrUpdate('categories', i, ['id', 'name', 'createdAt']));
    saveDatabaseNow(); invalidateCache();
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// ====== System Info ======
app.get('/api/system-info', requireAuth, (req, res) => {
  const c = (t, w = '') => { const r = db.exec(`SELECT COUNT(*) FROM ${t} ${w}`); return r.length > 0 ? r[0].values[0][0] : 0; };
  res.json({
    personnel: c('personnel', 'WHERE deletedAt IS NULL'),
    products: c('products', 'WHERE deletedAt IS NULL'),
    movements: c('movements', 'WHERE deletedAt IS NULL'),
    users: c('users'),
    warehouses: c('warehouses'),
    categories: c('categories'),
    audit: c('audit'),
    dbSize: fs.existsSync(DB_PATH) ? fs.statSync(DB_PATH).size : 0,
    backupCount: fs.existsSync(BACKUP_DIR) ? fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.sqlite')).length : 0
  });
});

// ====== SPA fallback ======
// ====== Restore missing public files from embedded backup ======
// اگر Windows Defender فایل‌ها را هنگام استخراج قرنطینه کرده باشد، این تابع آن‌ها را بازمی‌گرداند.
function restoreMissingPublicFiles() {
  const publicDir = path.join(__dirname, 'public');
  const iconsDir = path.join(publicDir, 'icons');
  if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });
  if (!fs.existsSync(iconsDir)) fs.mkdirSync(iconsDir, { recursive: true });
  let restored = 0;
  for (const [relPath, base64] of Object.entries(embeddedAssets || {})) {
    const fullPath = path.join(publicDir, relPath);
    const expectedSize = Buffer.from(base64, 'base64').length;
    let needRestore = !fs.existsSync(fullPath);
    // اگه فایل هست ولی حجمش فرق داره (احتمالاً ناقص)، بازسازی کن
    if (!needRestore && fs.statSync(fullPath).size !== expectedSize) needRestore = true;
    if (needRestore) {
      try {
        fs.writeFileSync(fullPath, Buffer.from(base64, 'base64'));
        console.log(`[restore] ✓ public/${relPath} (${expectedSize} bytes)`);
        restored++;
      } catch (e) {
        console.error(`[restore] ✗ Failed to restore ${relPath}:`, e.message);
      }
    }
  }
  if (restored > 0) console.log(`[restore] ${restored} file(s) restored from embedded backup.`);
  return restored;
}

// Fallback middleware: serve embedded content if static file is missing on disk
app.use((req, res, next) => {
  if (req.method !== 'GET') return next();
  if (req.path.startsWith('/api/')) return next();
  // فقط فایل‌های داخل embeddedAssets را چک کن
  const relPath = req.path.replace(/^\//, '');
  if (embeddedAssets && embeddedAssets[relPath]) {
    const diskPath = path.join(__dirname, 'public', relPath);
    if (!fs.existsSync(diskPath)) {
      const buf = Buffer.from(embeddedAssets[relPath], 'base64');
      const ext = path.extname(req.path).toLowerCase();
      const types = {
        '.html': 'text/html; charset=UTF-8',
        '.js': 'application/javascript; charset=UTF-8',
        '.json': 'application/json; charset=UTF-8',
        '.png': 'image/png',
      };
      res.set('Content-Type', types[ext] || 'application/octet-stream');
      res.set('X-Served-From', 'embedded-fallback');
      return res.send(buf);
    }
  }
  next();
});

app.get('*', (req, res) => {
  // اگه مسیر API بود و到这里 رسید، یعنی 404
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  const indexFile = path.join(__dirname, 'public', 'index.html');
  if (fs.existsSync(indexFile)) {
    return res.sendFile(indexFile);
  }
  // fallback: از نسخه‌ی embedded استفاده کن
  if (embeddedAssets && embeddedAssets['index.html']) {
    const html = Buffer.from(embeddedAssets['index.html'], 'base64').toString('utf-8');
    res.set('Content-Type', 'text/html; charset=UTF-8');
    res.set('X-Served-From', 'embedded-fallback');
    return res.send(html);
  }
  res.status(500).send('index.html missing and no fallback available');
});

// ====== Auto backup ======
function autoBackup() {
  try {
    saveDatabaseNow();
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    fs.writeFileSync(path.join(BACKUP_DIR, `backup_${ts}.sqlite`), Buffer.from(db.export()));
    const cutoff = Date.now() - 30 * 86400000;
    fs.readdirSync(BACKUP_DIR).forEach(f => {
      const fp = path.join(BACKUP_DIR, f);
      if (fs.statSync(fp).mtime.getTime() < cutoff) fs.unlinkSync(fp);
    });
  } catch (e) { console.error('Backup error:', e.message); }
}

async function start() {
  // بنر واضح برای تشخیص نسخه‌ی bulletproof از نسخه‌ی اصلی
  console.log('');
  console.log('============================================================');
  console.log('  SAMANE ANBAR v73 - BULLETPROOF EDITION');
  console.log('  Server: patched  |  Embedded backup: ' + (Object.keys(embeddedAssets).length > 0 ? 'YES' : 'NO'));
  console.log('  If you see THIS banner, you are running the CORRECT version.');
  console.log('  (Folder must be named: samane-anbar-v73)');
  console.log('============================================================');
  console.log('');
  await loadDatabase();
  // بازگردانی فایل‌های گم‌شده‌ی public/ از نسخه‌ی embedded
  try { restoreMissingPublicFiles(); } catch (e) { console.error('[restore] error:', e.message); }
  setInterval(autoBackup, 6 * 3600000);
  setTimeout(autoBackup, 5000);
  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`\nسرور در حال اجراست — آدرس: http://localhost:${PORT}\n`);
    setTimeout(() => { try { open('http://localhost:8080'); } catch (e) {} }, 1000);
  });
  // هندل خطای EADDRINUSE (پورت اشغال است)
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error('\n============================================================');
      console.error('خطا: پورت 8080 قبلاً در حال استفاده است!');
      console.error('احتمالاً یه سرور قدیمی هنوز داره اجرا می‌شه.');
      console.error('');
      console.error('راه‌حل:');
      console.error('  1. همه‌ی پنجره‌های مشکی (cmd) رو ببند');
      console.error('  2. Task Manager (Ctrl+Shift+Esc) رو باز کن');
      console.error('  3. همه‌ی پروسه‌های node.exe رو End Task کن');
      console.error('  4. دوباره start.bat رو اجرا کن');
      console.error('');
      console.error('یا اگه start.bat جدید رو اجرا کردی، خودش خودکار');
      console.error('پروسه‌های قدیمی روی پورت 8080 رو می‌بنده.');
      console.error('============================================================\n');
      process.exit(1);
    } else {
      console.error('خطای سرور:', err.message);
    }
  });
  process.on('uncaughtException', err => {
    if (err.code === 'EACCES') console.log('خطای دسترسی');
    else if (err.code === 'EADDRINUSE') { /* handled above */ }
    else console.error('خطای پیش‌بینی نشده:', err.message);
  });
  process.on('SIGINT', () => { saveDatabaseNow(); process.exit(0); });
  process.on('SIGTERM', () => { saveDatabaseNow(); process.exit(0); });
}
start();
