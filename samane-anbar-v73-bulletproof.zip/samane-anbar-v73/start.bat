@echo off
cd /d "%~dp0"
if not exist "node_modules" (
  echo Installing packages, please wait...
  call npm install --no-audit --no-fund
)
if not exist "data" mkdir data
if not exist "data\backups" mkdir "data\backups"
echo.
echo Cleaning up old server processes on port 8080...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8080" ^| findstr "LISTENING" 2^>nul') do (
  echo Killing old process PID: %%a
  taskkill /f /pid %%a 2>nul
)
echo.
echo ============================================================
echo  Samane Anbar v73 - Starting server...
echo  Open http://localhost:8080 in your browser
echo  Press Ctrl+C in this window to stop.
echo ============================================================
echo.
start "" http://localhost:8080
node server.js
pause
